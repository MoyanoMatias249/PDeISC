import Projects from '../components/Projects';

function ProjectsPage() {
  return (
    <section>
      <h2>Proyectos</h2>
      <Projects />
    </section>
  );
}

export default ProjectsPage;
