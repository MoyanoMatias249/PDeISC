function Experience() {
    return (
      <section id="experience">
        <h3>Experiencia</h3>
        <ul>
          <li>2022 - Estudios en una escuela tecnica en especialidad informatica</li>
          <li>2024 - Curso de HTML y CSS</li>
          <li>2025 - Cursos de JavaScript</li>
        </ul>
      </section>
    );
  }
  
  export default Experience;
  