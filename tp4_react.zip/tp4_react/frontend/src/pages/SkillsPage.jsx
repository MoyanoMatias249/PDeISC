import Skills from '../components/Skills';

function SkillsPage() {
  return (
    <section>
      <h2>Habilidades</h2>
      <Skills />
    </section>
  );
}

export default SkillsPage;
