// Arrays
const animales = [];
const productos = [];
const elementos = [];

// INGRESAR ELEMNTO AL ARREGLO ANIMALES
document.getElementById('form-1').addEventListener('submit', function (e) {
    e.preventDefault();
    const input = document.getElementById('animal-input');
    const valor = input.value.trim();
    if (valor) {
        animales.push(valor);
        actualizarLista(animales, 'animal-output');
        input.value = '';
    }
});
// ELIMINAR ULTIMA POSICION DE ARREGLO ANIMALES
document.getElementById('remove-animal').addEventListener('click', function () {
    if (animales.length > 0) {
        animales.pop();
        actualizarLista(animales, 'animal-output');
    } else {
        document.getElementById('animal-output').innerHTML = '<p>No hay animales para eliminar.</p>';
    }
});

// INGRESAR ELEMENTO AL ARREGLO ANIMALES
document.getElementById('form-2').addEventListener('submit', function (e) {
    e.preventDefault();
    const input = document.getElementById('producto-input');
    const valor = input.value.trim();
    
    if (valor) {
        productos.push(valor);
        actualizarLista(productos, 'producto-output');
        input.value = '';
    }
});

// ELIMINAR ULTIMA POSICION DE ARRAY PRODUCTOS, MOSTRAR ULTIMO BORRADO
document.getElementById('remove-producto').addEventListener('click', function () {
    const contenedor = document.getElementById('producto-output');

    if (productos.length > 0) {
        const eliminado = productos.pop();
        actualizarLista(productos, 'producto-output');

        const mensaje = `<p>Se eliminó: <strong>${eliminado}</strong></p>`;
        contenedor.insertAdjacentHTML('beforeend', mensaje);
    } else {
        contenedor.innerHTML = '<p>No hay productos para eliminar.</p>';
    }
});

// INGRESAR ELEMENTO AL ARREGLO FINAL
document.getElementById('form-3').addEventListener('submit', function (e) {
    e.preventDefault();
    const input = document.getElementById('elemento-input');
    const valor = input.value.trim();
    
    if (valor) {
        elementos.push(valor);
        actualizarLista(elementos, 'vaciar-output');
        input.value = '';
    }
});


// VACIAR ARREGLO
document.getElementById('vaciar-array').addEventListener('click', function () {
    while (elementos.length > 0) {
        elementos.pop();
    }

    const contenedor = document.getElementById('vaciar-output');
    contenedor.innerHTML = '<p>El array fue vaciado correctamente.</p>';
});

// GENERAR LISTA
function actualizarLista(array, contenedorId) {
    const contenedor = document.getElementById(contenedorId);
    if (array.length === 0) {
        contenedor.innerHTML = '<p>Lista vacía.</p>';
        return;
    }

    const html = `<ul>${array.map(item => `<li>${item}</li>`).join('')}</ul>`;
    contenedor.innerHTML = html;
}
