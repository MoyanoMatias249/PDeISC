import Contact from '../components/Contact';

function ContanctPage() {
  return (
    <section>
      <h2>Contacto</h2>
      <Contact />
    </section>
  );
}

export default ContanctPage;
